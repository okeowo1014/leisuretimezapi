from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db import transaction
from django.shortcuts import get_object_or_404

from .models import Wallet, Transaction
from .serializers import (
    WalletSerializer, TransactionSerializer, 
    DepositSerializer, WithdrawalSerializer, TransferSerializer
)
from index.wallet_utils import create_stripe_customer, create_payment_intent, create_payout,create_checkout_session


class WalletViewSet(viewsets.ModelViewSet):
    serializer_class = WalletSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        """Return only the authenticated user's wallet."""
        return Wallet.objects.filter(user=self.request.user)
    
    def perform_create(self, serializer):
        """Create a wallet for the authenticated user."""
        if Wallet.objects.filter(user=self.request.user).exists():
            return Response(
                {"detail": "You already have a wallet"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
            
        # Create Stripe customer if needed
        stripe_customer_id = None
        if self.request.user.email:
            stripe_customer_id = create_stripe_customer(self.request.user)
            
        serializer.save(user=self.request.user, stripe_customer_id=stripe_customer_id)
    
    @action(detail=True, methods=['post'])
    def deposit(self, request, pk=None):
        """Add funds to wallet using Stripe Checkout."""
        wallet = self.get_object()
        serializer = DepositSerializer(data=request.data)
        
        if serializer.is_valid():
            amount = serializer.validated_data['amount']
            
            # Check if specific payment method is provided or if using Checkout
            payment_method_id = serializer.validated_data.get('payment_method_id')
            success_url = serializer.validated_data.get('success_url')
            cancel_url = serializer.validated_data.get('cancel_url')
            
            # Get base URL from request
            base_url = request.build_absolute_uri('/').rstrip('/')
            
            # Use Stripe Checkout if success/cancel URLs are provided or no payment method
            if (success_url and cancel_url) or not payment_method_id:
                # Use provided URLs or defaults
                success_url = success_url or f"{base_url}/wallet/deposit/success"
                cancel_url = cancel_url or f"{base_url}/wallet/deposit/cancel"
                
                try:
                    # Create a pending transaction
                    transaction_obj = Transaction.objects.create(
                        wallet=wallet,
                        amount=amount,
                        transaction_type=Transaction.DEPOSIT,
                        status=Transaction.PENDING
                    )
                    
                    # Create Stripe Checkout session
                    checkout_session = create_checkout_session(
                        amount=amount,
                        customer_id=wallet.stripe_customer_id,
                        success_url=success_url,
                        cancel_url=cancel_url,
                        metadata={
                            'transaction_id': str(transaction_obj.id),
                            'wallet_id': str(wallet.id),
                            'user_id': str(wallet.user.id)
                        }
                    )
                    
                    # Update transaction with session ID
                    transaction_obj.stripe_payment_intent_id = checkout_session.id
                    transaction_obj.save()
                    
                    # Return checkout URL
                    return Response({
                        'checkout_url': checkout_session.url,
                        'session_id': checkout_session.id,
                        'transaction_id': str(transaction_obj.id)
                    })
                    
                except ValueError as e:
                    return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
            
            # If specifically requesting payment intent (legacy flow)
            else:
                try:
                    with transaction.atomic():
                        # Create Stripe payment intent
                        payment_intent = create_payment_intent(
                            amount=amount,
                            payment_method_id=payment_method_id,
                            customer_id=wallet.stripe_customer_id
                        )
                        
                        # Check if payment was successful
                        if payment_intent.status == 'succeeded':
                            # Add funds to wallet
                            transaction_obj = wallet.deposit(amount)
                            transaction_obj.stripe_payment_intent_id = payment_intent.id
                            transaction_obj.save()
                            
                            return Response({
                                'detail': 'Deposit successful',
                                'transaction': TransactionSerializer(transaction_obj).data
                            })
                        elif payment_intent.status == 'requires_action' or payment_intent.status == 'requires_confirmation':
                            # Return client secret for handling authentication on client side
                            return Response({
                                'requires_action': True,
                                'payment_intent_client_secret': payment_intent.client_secret,
                                'payment_intent_id': payment_intent.id
                            })
                        elif payment_intent.status == 'requires_payment_method':
                            # Create a transaction in pending state
                            transaction_obj = Transaction.objects.create(
                                wallet=wallet,
                                amount=amount,
                                transaction_type=Transaction.DEPOSIT,
                                status=Transaction.PENDING,
                                stripe_payment_intent_id=payment_intent.id
                            )
                            
                            # Return information needed for the client to complete payment
                            return Response({
                                'detail': 'Payment method required',
                                'payment_intent_id': payment_intent.id,
                                'client_secret': payment_intent.client_secret,
                                'transaction_id': str(transaction_obj.id)
                            })
                        else:
                            return Response({
                                'detail': f'Payment not completed. Status: {payment_intent.status}',
                                'payment_intent_id': payment_intent.id
                            }, status=status.HTTP_400_BAD_REQUEST)
                            
                except ValueError as e:
                    return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def withdraw(self, request, pk=None):
        """Withdraw funds from wallet."""
        wallet = self.get_object()
        serializer = WithdrawalSerializer(data=request.data)
        
        if serializer.is_valid():
            amount = serializer.validated_data['amount']
            
            try:
                with transaction.atomic():
                    # Process withdrawal
                    transaction_obj = wallet.withdraw(amount)
                    
                    # If you're implementing actual withdrawal to a bank account,
                    # you would handle Stripe payout here
                    # payout = create_payout(amount, wallet.user.stripe_account_id)
                    # transaction_obj.stripe_payment_intent_id = payout.id
                    # transaction_obj.save()
                    
                    return Response({
                        'detail': 'Withdrawal successful',
                        'transaction': TransactionSerializer(transaction_obj).data
                    })
                    
            except ValueError as e:
                return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    @action(detail=True, methods=['post'])
    def transfer(self, request, pk=None):
        """Transfer funds to another user's wallet."""
        wallet = self.get_object()
        serializer = TransferSerializer(data=request.data)
        
        if serializer.is_valid():
            recipient_id = serializer.validated_data['recipient_id']
            amount = serializer.validated_data['amount']
            
            try:
                # Find recipient's wallet
                recipient_wallet = get_object_or_404(Wallet, id=recipient_id)
                
                with transaction.atomic():
                    # Process transfer
                    transaction_obj = wallet.transfer(recipient_wallet, amount)
                    
                    return Response({
                        'detail': 'Transfer successful',
                        'transaction': TransactionSerializer(transaction_obj).data
                    })
                    
            except ValueError as e:
                return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
            except Wallet.DoesNotExist:
                return Response(
                    {'detail': 'Recipient wallet not found'}, 
                    status=status.HTTP_404_NOT_FOUND
                )
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['get'])
    def transactions(self, request, pk=None):
        """Get all transactions for the wallet."""
        wallet = self.get_object()
        transactions = Transaction.objects.filter(wallet=wallet).order_by('-created_at')
        
        # Optional filtering
        transaction_type = request.query_params.get('type')
        if transaction_type:
            transactions = transactions.filter(transaction_type=transaction_type)
            
        page = self.paginate_queryset(transactions)
        if page is not None:
            serializer = TransactionSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)
            
        serializer = TransactionSerializer(transactions, many=True)
        return Response(serializer.data)


class TransactionViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = TransactionSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        """Return only the authenticated user's transactions."""
        return Transaction.objects.filter(
            wallet__user=self.request.user
        ).order_by('-created_at')
    
    @action(detail=True, methods=['get'])
    def check_status(self, request, pk=None):
        """Check the status of a transaction with Stripe if applicable."""
        transaction = self.get_object()
        
        if transaction.stripe_payment_intent_id:
            # Here you would check with Stripe API for the current status
            # This is a simplified example
            return Response({
                'transaction': TransactionSerializer(transaction).data,
                'stripe_status': 'Would fetch from Stripe API'
            })
        
        return Response({
            'transaction': TransactionSerializer(transaction).data,
        })





# class WalletViewSet(viewsets.ModelViewSet):
#     serializer_class = WalletSerializer
#     permission_classes = [permissions.IsAuthenticated]
    
#     def get_queryset(self):
#         """Return only the authenticated user's wallet."""
#         return Wallet.objects.filter(user=self.request.user)
    
#     def perform_create(self, serializer):
#         """Create a wallet for the authenticated user."""
#         if Wallet.objects.filter(user=self.request.user).exists():
#             return Response(
#                 {"detail": "You already have a wallet"}, 
#                 status=status.HTTP_400_BAD_REQUEST
#             )
            
#         # Create Stripe customer if needed
#         stripe_customer_id = None
#         if self.request.user.email:
#             stripe_customer_id = create_stripe_customer(self.request.user)
            
#         serializer.save(user=self.request.user, stripe_customer_id=stripe_customer_id)
    
#     @action(detail=True, methods=['post'])
#     def deposit(self, request, pk=None):
#         """Add funds to wallet using Stripe."""
#         wallet = self.get_object()
#         serializer = DepositSerializer(data=request.data)
        
#         if serializer.is_valid():
#             amount = serializer.validated_data['amount']
#             payment_method_id = serializer.validated_data['payment_method_id']
            
#             try:
#                 with transaction.atomic():
#                     # Create Stripe payment intent
#                     payment_intent = create_payment_intent(
#                         amount=amount,
#                         customer_id=wallet.stripe_customer_id,
#                     )
                    
#                     # Check if payment was successful
#                     if payment_intent.status == 'succeeded':
#                         # Add funds to wallet
#                         transaction_obj = wallet.deposit(amount)
#                         transaction_obj.stripe_payment_intent_id = payment_intent.id
#                         transaction_obj.save()
                        
#                         return Response({
#                             'detail': 'Deposit successful',
#                             'transaction': TransactionSerializer(transaction_obj).data
#                         })
#                     else:
#                         return Response({
#                             'detail': f'Payment not completed. Status: {payment_intent.status}',
#                             'payment_intent_id': payment_intent.id
#                         }, status=status.HTTP_400_BAD_REQUEST)
                        
#             except ValueError as e:
#                 return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
#     @action(detail=True, methods=['post'])
#     def withdraw(self, request, pk=None):
#         """Withdraw funds from wallet."""
#         wallet = self.get_object()
#         serializer = WithdrawalSerializer(data=request.data)
        
#         if serializer.is_valid():
#             amount = serializer.validated_data['amount']
            
#             try:
#                 with transaction.atomic():
#                     # Process withdrawal
#                     transaction_obj = wallet.withdraw(amount)
                    
#                     # If you're implementing actual withdrawal to a bank account,
#                     # you would handle Stripe payout here
#                     # payout = create_payout(amount, wallet.user.stripe_account_id)
#                     # transaction_obj.stripe_payment_intent_id = payout.id
#                     # transaction_obj.save()
                    
#                     return Response({
#                         'detail': 'Withdrawal successful',
#                         'transaction': TransactionSerializer(transaction_obj).data
#                     })
                    
#             except ValueError as e:
#                 return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
#     @action(detail=True, methods=['post'])
#     def transfer(self, request, pk=None):
#         """Transfer funds to another user's wallet."""
#         wallet = self.get_object()
#         serializer = TransferSerializer(data=request.data)
        
#         if serializer.is_valid():
#             recipient_id = serializer.validated_data['recipient_id']
#             amount = serializer.validated_data['amount']
            
#             try:
#                 # Find recipient's wallet
#                 recipient_wallet = get_object_or_404(Wallet, id=recipient_id)
                
#                 with transaction.atomic():
#                     # Process transfer
#                     transaction_obj = wallet.transfer(recipient_wallet, amount)
                    
#                     return Response({
#                         'detail': 'Transfer successful',
#                         'transaction': TransactionSerializer(transaction_obj).data
#                     })
                    
#             except ValueError as e:
#                 return Response({'detail': str(e)}, status=status.HTTP_400_BAD_REQUEST)
#             except Wallet.DoesNotExist:
#                 return Response(
#                     {'detail': 'Recipient wallet not found'}, 
#                     status=status.HTTP_404_NOT_FOUND
#                 )
        
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#     @action(detail=True, methods=['get'])
#     def transactions(self, request, pk=None):
#         """Get all transactions for the wallet."""
#         wallet = self.get_object()
#         transactions = Transaction.objects.filter(wallet=wallet).order_by('-created_at')
        
#         # Optional filtering
#         transaction_type = request.query_params.get('type')
#         if transaction_type:
#             transactions = transactions.filter(transaction_type=transaction_type)
            
#         page = self.paginate_queryset(transactions)
#         if page is not None:
#             serializer = TransactionSerializer(page, many=True)
#             return self.get_paginated_response(serializer.data)
            
#         serializer = TransactionSerializer(transactions, many=True)
#         return Response(serializer.data)


# class TransactionViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = TransactionSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        """Return only the authenticated user's transactions."""
        return Transaction.objects.filter(
            wallet__user=self.request.user
        ).order_by('-created_at')
    
    @action(detail=True, methods=['get'])
    def check_status(self, request, pk=None):
        """Check the status of a transaction with Stripe if applicable."""
        transaction = self.get_object()
        
        if transaction.stripe_payment_intent_id:
            # Here you would check with Stripe API for the current status
            # This is a simplified example
            return Response({
                'transaction': TransactionSerializer(transaction).data,
                'stripe_status': 'Would fetch from Stripe API'
            })
        
        return Response({
            'transaction': TransactionSerializer(transaction).data,
        })